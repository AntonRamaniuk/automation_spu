package com.autotesting.framework.utils;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.autotesting.framework.testdata.ValidatePersonTestData;


public class RestConnect {
	
	private static HttpClient httpClient = new DefaultHttpClient();
	private static Logger logger = LoggerFactory.getLogger(RestConnect.class);
	
	
	//метод коннекта к рест сервису для скмв с хардкодным хедэром
	public static StringBuffer getResponseContentJson (String url, String content) {
		StringBuffer responseContent = new StringBuffer();
	    try {
	        HttpPost request = new HttpPost(url);
	        StringEntity params =new StringEntity(content);
	        request.addHeader("content-type", "application/json; charset=utf-8");
	        request.setEntity(params);
	        logger.info("[REST]: request to rest-skmv is sent witn contet: "+content);
	        HttpResponse response = httpClient.execute(request);
	        logger.info("[REST]: Response code obtained: "+response);
			BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
			String line = "";
			while ((line = rd.readLine()) != null) {
				responseContent.append(line);
				logger.info("[REST]: Response content obtained: "+responseContent);
			}
	    }catch (Exception ex) {
	    	ex.printStackTrace();
	    	logger.error("[REST]: ERROR: "+ex);
	    } finally {
	        httpClient.getConnectionManager().shutdown();
	        logger.info("[REST]: Connection to rest is closed");
	    }
		return responseContent;
	}
	
	//private final String USER_AGENT = "Mozilla/5.0";
	 
	public static void main(String[] args) throws Exception {
		//StringBuffer test=  RestConnect.getResponseContentJson("http://192.168.5.77:9080/spu-interfaces/api/person/getPerson", "{\"number\": \"001-001-041 20\"}");
		//String bufFileBeforeEncoding = "{\"name\":{\"lastName\":\"ЗУБРОВА\",\"firstName\":\"ИРИНА\",\"middleName\":\"НИКОЛАЕВНА\"},\"genderCode\":\"Ж\",\"birthDate\":{\"day\": 13,\"month\": 9,\"year\":1971}}";
		String bufFileBeforeEncoding = ValidatePersonTestData.returnTestData("validate_person_smoke_test.txt");
		byte[] resultByteFileUTF8 = bufFileBeforeEncoding.getBytes("UTF8");
		String resultFileUTF8 = new String(resultByteFileUTF8, "UTF8");

		
		StringBuffer test=  RestConnect.getResponseContentJson("http://192.168.5.77:9080/spu-interfaces/api/person/validatePerson", resultFileUTF8);

		System.out.println("Contenttest: "+test);
	} 
}


