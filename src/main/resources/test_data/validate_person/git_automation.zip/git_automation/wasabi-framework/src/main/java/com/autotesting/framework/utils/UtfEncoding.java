package com.autotesting.framework.utils;

public class UtfEncoding {

}
