package com.autotestting.framework.primaryFiles;

public class LoadPrimaryFilesRest {

}
